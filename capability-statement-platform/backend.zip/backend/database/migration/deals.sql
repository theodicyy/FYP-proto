USE capability_statement_db;

ALTER TABLE deals
  -- Multi Select -> JSON (store arrays like ["Linkedin","Website"])
  ADD COLUMN publicity_purposes JSON NULL,
  ADD COLUMN confidentiality JSON NULL,
  ADD COLUMN transaction_types JSON NULL,
  ADD COLUMN srb_related JSON NULL,
  ADD COLUMN pe_related JSON NULL,
  ADD COLUMN startup_or_vc_related JSON NULL,
  ADD COLUMN featured_other_areas JSON NULL,
  ADD COLUMN deal_pg JSON NULL,

  -- Single Select -> VARCHAR (flexible; can convert to ENUM later)
  ADD COLUMN notability VARCHAR(255) NULL,
  ADD COLUMN acting_for VARCHAR(255) NULL,
  ADD COLUMN referral VARCHAR(255) NULL,
  ADD COLUMN partner_approval VARCHAR(255) NULL,

  -- Long notes -> TEXT
  ADD COLUMN deal_summary TEXT NULL,
  ADD COLUMN significant_features TEXT NULL,
  ADD COLUMN notable_reason TEXT NULL,
  ADD COLUMN business_desc_of_parties TEXT NULL,
  ADD COLUMN target_nationandbiz_desc TEXT NULL,
  ADD COLUMN acquiror_nationandbiz_desc TEXT NULL,
  ADD COLUMN deal_media TEXT NULL,
  ADD COLUMN remarks TEXT NULL,
  ADD COLUMN past_clients TEXT NULL,

  -- Everything else -> VARCHAR
  ADD COLUMN parties_advised_coyname VARCHAR(255) NULL,
  ADD COLUMN parties_advised_name VARCHAR(255) NULL,
  ADD COLUMN parties_advised_designation VARCHAR(255) NULL,
  ADD COLUMN parties_advised_telephone VARCHAR(50) NULL,
  ADD COLUMN parties_advised_email VARCHAR(255) NULL,
  ADD COLUMN industry_of_parties_advised VARCHAR(255) NULL,

  ADD COLUMN other_firms_involved VARCHAR(255) NULL,
  ADD COLUMN other_firms_partners VARCHAR(255) NULL,
  ADD COLUMN other_firms_sa VARCHAR(255) NULL,
  ADD COLUMN other_firms_a VARCHAR(255) NULL,

  ADD COLUMN wongp_lawyers_partners VARCHAR(255) NULL,
  ADD COLUMN wongp_lawyers_sa VARCHAR(255) NULL,
  ADD COLUMN wongp_lawyers_a VARCHAR(255) NULL,

  ADD COLUMN referral_party VARCHAR(255) NULL,

  ADD COLUMN jurisdiction VARCHAR(255) NULL,
  ADD COLUMN deal_industry_t1 VARCHAR(255) NULL,
  ADD COLUMN deal_industry_t2 VARCHAR(255) NULL,

  ADD COLUMN partner_initial VARCHAR(255) NULL,

  -- Proper types
  ADD COLUMN file_open_date DATE NULL,
  ADD COLUMN date_announced DATE NULL,
  ADD COLUMN date_completed DATE NULL,

  -- Important: you *already have* deal_value and deal_currency in your current schema.
  -- If you run this line as-is, it will error ("Duplicate column name").
  -- So we only add currency_type, not deal_value.
  ADD COLUMN currency_type VARCHAR(16) NULL;
