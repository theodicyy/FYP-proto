<template>
  <div class="flex flex-col items-center justify-center h-[70vh] text-center">

    <div class="text-green-600 text-6xl mb-4">✓</div>

    <h1 class="text-3xl font-bold mb-2">
      Document Generated
    </h1>

    <p class="text-gray-600 mb-6">
      Your capability statement has been downloaded successfully.
    </p>

    <router-link to="/configuration" class="btn btn-primary">
      Generate Another
    </router-link>

  </div>
</template>
